public class StudentPQMain {

    public static void main (String[] args) {

        StudentPQ studentPQ = new StudentPQ();

    } // method main

} // class StudentPQMain
