public class HuffmanMain {


    public static void main (String[] args) {

        Huffman huffman = new Huffman();

    } // method main


} // class HuffmanMain


