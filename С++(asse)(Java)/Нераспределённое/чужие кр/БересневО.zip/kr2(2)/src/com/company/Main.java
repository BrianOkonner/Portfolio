package com.company;

import java.io.*;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

class cmp_date implements Comparator <Poezdka>{

    @Override
    public int compare(Poezdka poezdka, Poezdka t1) {
        return 0;
    }
}


public class Main {

    public static void main(String[] args) throws IOException{
    try {
        BufferedReader bufRead1 = new BufferedReader(new InputStreamReader(
                new FileInputStream("in.txt")));

        FileOutputStream outFile = new FileOutputStream("out.txt");

        Poezdka arrPoez[] = new Poezdka[8];
        PrintStream printStream = new PrintStream(outFile);
        int count =0;
        String line;
        while ((line = bufRead1.readLine()) != null) {
            String[] arr = line.split(",");
            //    private int numberCar;
            //    private Mark mark;
            //    private String famil;
            //    private int date;
            //    private int mass;
            int lnum = Integer.valueOf(arr[0]);
            Mark lm = Mark.valueOf(arr[1]);
            String lfam = arr[2];
            int ldate = Integer.valueOf(arr[3]);
            int lmass = Integer.valueOf(arr[4]);
            arrPoez[count] = new Poezdka(lnum,lm,lfam,ldate,lmass);
            count++;
        }
        bufRead1.close();

        AutoPark my_park = new AutoPark("my_park","ulica Voronynskogo 15/2", arrPoez);
        printStream.println(my_park.toString());

        for(Poezdka i: my_park.getArrPoez())
            if (i.getMass()>4)
                printStream.println(i.toString());

        double sr1 =0;
        double sr2 =0;
        double sr3 =0;
        double sr4 =0;
        double sr5 =0;
        double sr6 =0;
        double sr7 =0;
        double sr8 =0;
        int c1 =0;
        int c2 =0;
        int c3 =0;
        int c4 =0;
        int c5 =0;
        int c6 =0;
        int c7 =0;
        int c8 =0;
        int n1 =my_park.getArrPoez()[0].getNumberCar();
        int n2 =my_park.getArrPoez()[1].getNumberCar();
        int n3 =my_park.getArrPoez()[2].getNumberCar();
        int n4 =my_park.getArrPoez()[3].getNumberCar();
        int n5 =my_park.getArrPoez()[4].getNumberCar();
        int n6 =my_park.getArrPoez()[5].getNumberCar();
        int n7 =my_park.getArrPoez()[6].getNumberCar();
        int n8 =my_park.getArrPoez()[7].getNumberCar();

        for(Poezdka i: my_park.getArrPoez()){
            if(i.getNumberCar()== n1){
                sr1+=i.getMass();
                c1++;
            }

            if(i.getNumberCar()== n2){
                sr2+=i.getMass();
                c2++;
            }
            if(i.getNumberCar()== n3){
                sr3+=i.getMass();
                c3++;
            }
            if(i.getNumberCar()== n4){
                sr4+=i.getMass();
                c4++;
            }
            if(i.getNumberCar()== n5){
                sr5+=i.getMass();
                c5++;
            }
            if(i.getNumberCar()== n6){
                sr6+=i.getMass();
                c6++;
            }
            if(i.getNumberCar()== n7){
                sr7+=i.getMass();
                c7++;
            }
            if(i.getNumberCar()== n8){
                sr8+=i.getMass();
                c8++;
            }
        }
        sr1 /= c1;
        sr2 /= c2;
        sr3 /= c3;
        sr4 /= c4;
        sr5 /= c5;
        sr6 /= c6;
        sr7 /= c7;
        sr8 /= c8;
        printStream.println(sr1+
        sr2 +
        sr3 +
        sr4+
        sr5 +
        sr6 +
        sr7 +
        sr8 );


        int summMassToyota = 0;
        int summMassMersedes = 0;
        int summMassJeep = 0;
            for(Poezdka i: my_park.getArrPoez()){
                if(i.getMark().equals(Mark.Toyota))
                    summMassToyota+=i.getMass();
                if(i.getMark().equals(Mark.Mersedes))
                    summMassMersedes+=i.getMass();
                if(i.getMark().equals(Mark.Jeep))
                    summMassJeep+=i.getMass();
            }
        printStream.println("SummToyota:"+summMassToyota);
        printStream.println("SummMersedes:"+summMassMersedes);
        printStream.println("SummJeep:"+summMassJeep);


            /*case 1:
                printStream.println(arrFirm.getNameOfFirm());
                //strToPrint = arrFirm.getArrSotrFirmp().toString();
                printStream.println(arrFirm.toString());

                    *//*for (String current : strToPrint) {
                        printStream.println(current);
                    }*//*
                break;
            case 2:
                printStream.println(arrFirm.getNameOfFirm()+"\n");
                System.out.println("введите должность");
                String job = sc2.nextLine();
                for(SotrFirm i:arrFirm.getArrSotrFirmp())
                    if (i.getJobOfSotr().equals(job))
                        printStream.println(i.toString());

                break;
            case 3:
                printStream.println(arrFirm.getNameOfFirm()+"\n");
                System.out.println("введите год");
                int lYear = sc1.nextInt();
                for(SotrFirm i:arrFirm.getArrSotrFirmp())
                    if (i.getYearOfBirth()>= lYear)
                        printStream.println(i.toString());

                break;
            case 4:
                printStream.println(arrFirm.getNameOfFirm()+"\n");
                System.out.println("введите отдел");
                String lotdel = sc1.nextLine();
                for(SotrFirm i:arrFirm.getArrSotrFirmp())
                    if (i.getNameOfOtdel().equalsIgnoreCase(lotdel))
                        printStream.println(i.toString());

                break;
            case 5:
                printStream.println(arrFirm.getNameOfFirm()+"\n");
                Arrays.sort(arrFirm.getArrSotrFirmp(), new cmpRevOclad());
                for(SotrFirm i:arrFirm.getArrSotrFirmp())
                    printStream.println(i.toString());
                break;
            case 6:
                printStream.println(arrFirm.getNameOfFirm()+"\n");
                Arrays.sort(arrFirm.getArrSotrFirmp(), new cmpFIO());
                for(SotrFirm i:arrFirm.getArrSotrFirmp())
                    printStream.println(i.toString());
                break;
            case 7:
                printStream.println(arrFirm.getNameOfFirm()+"\n");
                printStream.println(SotrFirm.getCount());
                break;*/

        outFile.close();
        Poezdka a[] = my_park.getArrPoez();
        System.out.println(a[7].getCount());

    }
    catch (WrongInput e){
        System.out.println(e.getMessage());
    }

    }
}
