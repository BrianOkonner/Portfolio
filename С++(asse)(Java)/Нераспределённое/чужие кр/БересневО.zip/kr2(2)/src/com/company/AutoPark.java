package com.company;

import java.util.Arrays;

public class AutoPark {
    private String name;
    private String addr;
    private Poezdka arrPoez[];

    public AutoPark(){
        this.name = null;
        this.addr = null;
        arrPoez = null;
    }


    public AutoPark(String lname, String laddr, Poezdka[] larrPoez)throws WrongInput{
        this.name = lname;
        this.addr = laddr;
        arrPoez = new Poezdka[larrPoez.length];
        for(int i=0;i<larrPoez.length;i++){
            arrPoez[i] = larrPoez[i];
        }

    }

    @Override
    public String toString() {
        return "Autopark:name"+this.name+",addr:"+this.addr+ Arrays.toString(this.getArrPoez());
    }

    public String getName() {
        return name;
    }

    public String getAddr() {
        return addr;
    }

    public Poezdka[] getArrPoez() {
        return arrPoez;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public void setArrPoez(Poezdka[] arrPoez) {
        this.arrPoez = arrPoez;
    }

    public void setName(String name) {
        this.name = name;
    }
}
