package com.company;

enum Mark{Toyota, Mersedes, Jeep }

class WrongInput extends Exception{}

public class Poezdka {
    private final int id;
    private int numberCar;
    private Mark mark;
    private String famil;
    private int date;
    private int mass;
    private int count = 0;

    Poezdka(){
        id = count;
        count++;
        numberCar = 0;
        mark = null;
        famil = null;
        date = 0;
        mass = 0;
    }

    Poezdka(int lnum, Mark lm, String lfam, int ldate, int lmass)throws WrongInput{
        id = count;
        count++;
        if (lnum<0 || lfam.equals("") ||ldate<0||lmass<0)
            throw new WrongInput();
        numberCar = lnum;
        mark = lm;
        famil = lfam;
        date = ldate;
        mass = lmass;
    }

    @Override
    public String toString() {
        return "Poezd:id"+this.id+",numb"+this.numberCar+",mark:"+this.mark+",famil:"+this.famil+",date:"+this.date+",mass"+this.mass;
    }

    public int getCount() {
        return count;
    }

    public int getId() {
        return id;
    }

    public int getDate() {
        return date;
    }

    public int getMass() {
        return mass;
    }

    public int getNumberCar() {
        return numberCar;
    }

    public Mark getMark() {
        return mark;
    }

    public String getFamil() {
        return famil;
    }

    public void setCount(int count)
    {
        this.count = count;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public void setFamil(String famil) {
        this.famil = famil;
    }

    public void setMark(Mark mark) {
        this.mark = mark;
    }

    public void setMass(int mass) {
        this.mass = mass;
    }

    public void setNumberCar(int numberCar) {
        this.numberCar = numberCar;
    }
}
