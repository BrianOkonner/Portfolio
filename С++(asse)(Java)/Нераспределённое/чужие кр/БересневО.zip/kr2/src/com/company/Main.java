package com.company;
import java.util.Arrays;
import java.util.Comparator;

class cmp_plosch implements Comparator<Figure>{

    @Override
    public int compare(Figure figure, Figure t1) {
        if (figure.my_plosch() < t1.my_plosch())
            return -1;
        return 1;
    }
}


class WrongStor extends Exception{}

class My_Kvadr implements Figure{
    private Point centrKvar;
    private int storona;

    My_Kvadr(){
        centrKvar = new Point();
        storona = 0;
    }

    My_Kvadr(int x,int y, int stor){
        centrKvar = new Point(x,y);
        storona = stor;
    }

    My_Kvadr(int stor)throws WrongStor{
        centrKvar = new Point();
        if (stor<0)
            throw new WrongStor();
        storona = stor;
    }

    @Override
    public Point my_centr() {
        return this.centrKvar;
    }

    @Override
    public double my_plosch() {
        return storona*storona;
    }

    @Override
    public String toString() {
        return "Kvadr:storona:"+this.storona+",centr:"+centrKvar.toString();
    }

    public void setCentrKvar(Point centrKvar) {
        this.centrKvar = centrKvar;
    }

    public void setStorona(int storona) {
        this.storona = storona;
    }

    public int getStorona() {
        return storona;
    }

    public Point getCentrKvar() {
        return centrKvar;
    }
}

class My_Elips implements Figure{
    private Point centrEl;
    private int storonaA;
    private int storonaB;


    My_Elips(){
        centrEl = new Point();
        storonaA = 0;
        storonaB = 0;
    }

    My_Elips(int x,int y, int storA, int storB){
        centrEl = new Point(x,y);
        storonaA = storA;
        storonaB = storB;
    }

    My_Elips(int storA, int storB)throws WrongStor{
        centrEl = new Point();
        if (storA<0 || storB<0)
            throw new WrongStor();
        storonaA = storA;
        storonaB = storB;
    }

    @Override
    public Point my_centr() {
        return this.centrEl;
    }

    @Override
    public double my_plosch() {
        return storonaA*storonaB*Math.PI;
    }

    @Override
    public String toString() {
        return "Elips:storonaA:"+this.storonaA+",storonaB:"+this.storonaB+",centr:"+centrEl.toString();
    }

    public void setCentrEl(Point centrEl) {
        this.centrEl = centrEl;
    }

    public void setStoronaA(int storonaA) {
        this.storonaA = storonaA;
    }

    public void setStoronaB(int storonaB) {
        this.storonaB = storonaB;
    }

    public int getStoronaA() {
        return storonaA;
    }

    public int getStoronaB() {
        return storonaB;
    }

    public Point getCentrEl() {
        return centrEl;
    }

}

public class Main  {

    public static void main(String[] args) {
        try{
            Figure arrFig[] = new Figure[4];
            arrFig[0] = new My_Kvadr(15);
            arrFig[1] = new My_Kvadr();
            arrFig[2] = new My_Elips(15,15);
            arrFig[3] = new My_Elips();


            System.out.println(Arrays.toString(arrFig));
            Arrays.sort(arrFig, new cmp_plosch());
            System.out.println(Arrays.toString(arrFig));

        }
        catch (WrongStor e)
        {
            System.out.println(e.toString());
        }




    }
}
