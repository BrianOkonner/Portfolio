SELECT TOP (1000) [FIO]
,[spez]
      ,[Data]
  FROM [Lab4].[dbo].[Student]