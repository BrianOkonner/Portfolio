select	*
from
		Student
order by	
		spez desc, godpost desc, FIO;