select	*
from
		Student
order by	
		Data desc;