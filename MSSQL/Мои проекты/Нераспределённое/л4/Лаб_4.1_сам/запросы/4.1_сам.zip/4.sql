select	distinct
		godpost
from
		Student;