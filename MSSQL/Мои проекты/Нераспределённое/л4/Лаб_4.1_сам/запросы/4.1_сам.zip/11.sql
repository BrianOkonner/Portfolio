select
		*
from
		Student
order by	
		Data
		OFFSET 4 rows;