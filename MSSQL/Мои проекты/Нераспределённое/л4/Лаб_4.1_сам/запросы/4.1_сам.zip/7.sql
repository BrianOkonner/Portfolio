select	top 1
		*
from
		Student
order by	
		FIO desc;	