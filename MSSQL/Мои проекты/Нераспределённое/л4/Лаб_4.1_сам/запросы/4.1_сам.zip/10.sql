select
		*
from
		Student
order by	
		godpost
		OFFSET 0 rows
		fetch next 5 rows ONLY