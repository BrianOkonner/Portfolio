select	top 10 percent
		*
from
		Student
order by	
		godpost;