use Lab4
select *
from Products 
where 
Price >= 20000 and  Price <= 40000