use Lab4
select *
from Products 
where 
Manufacturer = 'samsung' or Price > 50000