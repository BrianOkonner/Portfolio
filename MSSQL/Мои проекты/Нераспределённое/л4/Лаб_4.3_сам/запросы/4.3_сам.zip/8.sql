use Lab4
select *
from Products 
where 
Manufacturer = 'samsung' or
Manufacturer = 'Huawei' or
Manufacturer = 'Xiaomi' 