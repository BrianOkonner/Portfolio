use Lab4
select *
from Products 
where 
Price > 45000