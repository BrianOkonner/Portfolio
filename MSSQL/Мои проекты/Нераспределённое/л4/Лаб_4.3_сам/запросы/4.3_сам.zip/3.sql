use Lab4
select *
from Products 
where 
Price * ProductCount > 200000