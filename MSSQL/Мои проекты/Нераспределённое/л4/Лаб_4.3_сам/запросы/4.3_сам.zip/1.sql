use Lab4
select *
from Products 
where 
Price like 'Samsung'