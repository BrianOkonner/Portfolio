SELECT
  (MAX(PL) / MIN(PL)) as Raz
FROM
  Tabl_Kontinent$;