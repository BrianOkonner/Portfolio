use TestDatabas;
select
 Min(PL) as min_PL from Tabl_Kontinent$