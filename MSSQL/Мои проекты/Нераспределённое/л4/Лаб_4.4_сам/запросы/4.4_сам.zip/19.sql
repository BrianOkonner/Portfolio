select
 round(Avg(cast(KolNas as float)), 1)
 as SR_KolNas from Tabl_Kontinent$